package com.learn.amazonshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmazonshopApplicationTests {

	@Test
	void contextLoads() {
	}

}
