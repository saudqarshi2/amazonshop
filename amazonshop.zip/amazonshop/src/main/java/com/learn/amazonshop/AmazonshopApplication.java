package com.learn.amazonshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmazonshopApplication {

	public static void main(String[] args) {
		SpringApplication.run(AmazonshopApplication.class, args);
	}

}
